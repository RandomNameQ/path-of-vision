﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Poe_show_buff.settings
{
    public class ProgramSettings
    {
        private string pathToBuffFolder = @"\Icons\Buff";
        private string pathToDebuffFolder = @"\Icons\Buff";




    }
}
